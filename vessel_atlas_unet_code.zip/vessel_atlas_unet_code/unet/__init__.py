import os
import pkgutil
from .net_helper import *

# pkgpath = os.path.dirname(__file__)
# pkgname = os.path.basename(pkgpath)
#
# for _, file, _ in pkgutil.iter_modules([pkgpath]):
#     # print(pkgname + '.' + file)
#     __import__(pkgname + '.' + file)