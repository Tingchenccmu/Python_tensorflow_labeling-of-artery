
from operator import mul
from functools import reduce
from net_helper import *
import numpy as np

class Model3d():
    def __init__(self, input_x, **kwargs):
        self.input = input_x
        self.depth = kwargs['depth']
        self.layer_channel_list = kwargs['channels']
        self.groups = kwargs['groups']
        self.in_shape = kwargs['input_size']
        self.n_class = kwargs['n_class']
        self.activation = kwargs['activation'] # last layer
        self.init_method = kwargs.get('init_method', 'default')
        self.keep_prob = float(kwargs.get('keep_prob',1.0))
        self.normalize = kwargs.get('normalize', 'bn')
        self.pool_strides = kwargs.get('pool_strides', (2,2,2))
        self.batch_size = kwargs.get('batch_size', 1)
        self.training = kwargs.get('training', True)
        
        self.output = None
        
    def preduce_input(self):
        c = 1
        b = self.batch_size
        if len(self.in_shape) == 3:
            d, h, w = self.in_shape
        if len(self.in_shape) == 4:
            if self.in_shape[0] != self.batch_size:
                d, h, w, c = self.in_shape
            else:
                b, d, h, w  = self.in_shape
        in_tensor_shape = (b, d, h, w, c)
        self.input = tf.reshape(self.input, in_tensor_shape)
        
    def conv3d(self, input_x, kernel_size, out_channels, strides, name_scope):
        cin = input_x.get_shape().as_list()[-1]
        initializer = get_initializer(self.init_method, kernel_size, cin)
        if initializer is None:
            # use default method
            output = tf.layers.conv3d(input_x, filters=out_channels, kernel_size=kernel_size, strides=strides, padding='same') 
        else:
            output = tf.layers.conv3d(input_x, filters=out_channels, kernel_size=kernel_size, strides=strides, kernel_initializer=initializer, padding='same') 
        # normalization
        if self.normalize == 'gn':
            output = Group_norm3d(output, min(out_channels//2, 32), name_scope='gn_'+name_scope)
#             output = tf.contrib.layers.group_norm(inputs=output,groups=min(out_channels//2,32))
#             output = tf.contrib.layers.group_norm(inputs=output,groups=self.groups)
        else:
            output = tf.layers.batch_normalization(output, training=self.training)
        # relu activation
        output = tf.nn.relu(output)
        return output
    
    def conv3d_dilated(self, input_x, out_channels, drate=1):
        return tf.layers.conv3d(input_x, filters=out_channels, kernel_size=3, strides=1, dilation_rate=(drate,drate,1), padding='same')
    
    def max_pooling(self, input_x):
        return tf.layers.max_pooling3d(input_x, pool_size=(2, 2, 2), strides=self.pool_strides, padding='same')

    def conv_transpose(self, input_x, kernel_size, out_channels, name_scope):
        cin = input_x.get_shape().as_list()[-1]
        initializer = get_initializer(self.init_method, kernel_size, cin)
        if initializer is None:
            output = tf.layers.conv3d_transpose(input_x, filters=out_channels, kernel_size=kernel_size, strides=self.pool_strides, padding='same')
        else:
            output = tf.layers.conv3d_transpose(input_x, filters=out_channels, kernel_size=kernel_size, strides=self.pool_strides, kernel_initializer=initializer, padding='same')
        if self.normalize == 'gn':
            output = Group_norm3d(output, min(out_channels // 2, 32), name_scope='gn_' + name_scope)
        #             output = tf.contrib.layers.group_norm(inputs=output,groups=min(out_channels//2,32))
        #             output = tf.contrib.layers.group_norm(inputs=output,groups=self.groups)
        else:
            output = tf.layers.batch_normalization(output, training=self.training)
        # relu activation
        output = tf.nn.relu(output)
        return output
    
    def conv_block(self, input_x, layer_idx, num_layers, num_channels, kernel_size=3, strides=1):
        print(f'conv{layer_idx}', flush=True)
        if layer_idx == 0:
            kernel_size = 3

        with tf.variable_scope(f'conv{layer_idx}',reuse=tf.AUTO_REUSE):
            if num_layers == 1:
                return self.conv3d(input_x, 3, num_channels, strides=strides, name_scope='0')
            conv1 = self.conv3d(input_x, 1, num_channels, strides=strides, name_scope='res0')
            x = input_x
            for i in range(num_layers):
               if layer_idx != 0 and layer_idx%3 == 0 and i == 0:
                    tf.add_to_collection('checkpoints', x)
                if i == 0 and num_layers != 1:
                    x = self.conv3d(x, kernel_size, num_channels, strides=strides, name_scope=str(i))
                else:
                    x = self.conv3d(x, kernel_size, num_channels, strides=1, name_scope=str(i))
                print(i, 'x.shape', x.shape, flush=True)
            return conv1 + x
        
    def _up(self, input, simi_level_in, layer_idx, num_layers, num_channels, last_output=None):
        print(f'up{layer_idx}', flush=True)
        with tf.variable_scope(f'conv{layer_idx}', reuse=tf.AUTO_REUSE):
            m = self.conv_transpose(input, 2, num_channels, name_scope='0')
            n = tf.concat(values=[simi_level_in, m], axis=4)
            output = self.conv_block(n, layer_idx, num_layers, num_channels)
            if last_output != None:
                ch = last_output.get_shape().as_list()[-1]
        #       print('last data shape: ', last_output.shape)
                last_output = self.conv_transpose(last_output, 2, ch//2, name_scope='1')
                copy_output = tf.concat([last_output, output], axis=4)
            else:
                copy_output = output
            return output, copy_output

    def level_block(self, m, layer_idx):
        # input: m
        last_data = None
#         if layer_idx != 0 and layer_idx % 3 == 0:
            
        num_layers, out_ch = self.layer_channel_list[layer_idx+1]
        if layer_idx < self.depth:
            n = self.conv_block(m, layer_idx, num_layers, out_ch, strides=1)
            m = self.max_pooling(n)
            m, last_data = self.level_block(m, layer_idx+1)
            m, last_data = self._up(m, n, 2*self.depth-layer_idx, num_layers, out_ch, last_data)
        else:
            # dropout
            if self.keep_prob != 1:
                print('self.keep_prob: ', self.keep_prob)
                m = tf.nn.dropout(m, self.keep_prob)
            m = self.conv_block(m, layer_idx, num_layers, out_ch, strides=1)
        return m, last_data

    def head(self, input_, initializer):
        with tf.variable_scope(f'last_conv', reuse=tf.AUTO_REUSE):
            if self.activation == 'sigmoid':
                self.n_class = 1
            if initializer is None:
                output = tf.layers.conv3d(input_, filters=self.n_class, kernel_size=1, strides=1,
                                          padding='same')
            else:
                output = tf.layers.conv3d(input_, filters=self.n_class, kernel_size=1, strides=1,
                                          kernel_initializer=initializer, padding='same')
            print('output.shape', output.shape, flush=True)
            if self.activation == 'sigmoid':
                self.output = tf.sigmoid(output)
            else:
                self.output = tf.nn.softmax(output)
            return output

    def inference(self):
        self.preduce_input()
        self.input = tf.identity(self.input, name='input')
        output, merge_deep_super = self.level_block(self.input, 0)
        print('last output.shape', merge_deep_super.shape, flush=True)
        cin = merge_deep_super.get_shape().as_list()[-1]
        initializer = get_initializer(self.init_method, 1, cin)
        self.head(merge_deep_super, initializer)
        return self.output

    def count_params(self):
        total_parameters = 0
        for v in tf.trainable_variables():
            shape = v.get_shape()
            variable_parameters = 1
            for dim in shape:
                variable_parameters *= dim.value
            # if 'gamma' in v.name or 'beta' in v.name:
            print(v.name, ': ', shape, variable_parameters)
            total_parameters += variable_parameters
        print('total trainable parameters: ', total_parameters)
        return total_parameters

def get_num_params():
    num_params = 0
    for variable in tf.trainable_variables():
        shape = variable.get_shape()
        num_params += reduce(mul, [dim.value for dim in shape], 1)
    return num_params

if __name__ == '__main__':
    input_shape = [128,128,128]
    channels = [[1,1], [1,8], [2,16], [3,32], [3,64], [3,128]]
    n_class = 45
    x = tf.random_uniform(input_shape)
    model = Model3d(x, depth=4, channels=channels, groups=4, activation='softmax',
                          n_class=n_class, input_size=input_shape, normalize='gn')
    pred = model.inference()
    model.count_params()

    # with tf.Session() as sess:
    #     sess.run(pred)

    # print('params count: ', np.sum([np.prod(v.get_shape().as_list()) for v in tf.trainable_variables()]))
    # print('params count: ', get_num_params())
