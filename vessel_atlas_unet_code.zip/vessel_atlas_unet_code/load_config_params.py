
import os
from read_config import *
import time

instances_param_names = ['label_confidence', 'channels', 'input_size', 'n_class',  'class_weights', 'batch_size', 'keep_prob', 'learning_rate', 'shrink', 'depth', 'epochs', 'show_step', 'groups','aug_choice', 'decay_steps', 'is_augmentation', 'warmup','warmup_step', 'random_crop', 'compress', 'img_normalize','echo', 'save_result_switch','maxpooling', 'class_relation_weights', 'add_err']


def load_params(config_filepath, type):
    time_now = time.strftime('%Y%m%d%H-%M', time.localtime())
    cf = Config(config_filepath)
    sec2 = 'train_params'
    params = cf.get_config_dict(sec2)

    tag = params['tag']
    print('tag:', tag)

    sec1 = 'filepath'
    model_dir = cf.getconfig(sec1, 'model_dir')
    data_list = []
    if type == 'train':
        log_dir = cf.getconfig(sec1, 'log_dir')
        log_dir = os.path.join(log_dir, tag + '_' + time_now)
        params['log_dir'] = log_dir
        model_dir = os.path.join(model_dir, tag + '_' + time_now)
        train_data_dir = cf.getconfig(sec1, 'train_data_dir')
        val_data_dir = cf.getconfig(sec1, 'val_data_dir')
        train_path_list = []
        val_path_list = []
        for f in os.listdir(train_data_dir):
            if '.tfrecords' in f:
                train_path_list.append(os.path.join(train_data_dir, f))
        for f in os.listdir(val_data_dir):
            if '.tfrecords' in f:
                val_path_list.append(os.path.join(val_data_dir, f))
        data_list = [train_path_list, val_path_list]
        if cf.has_option(sec1, 'pretrain_model'):
            pretrain_model = cf.getconfig(sec1, 'pretrain_model')
            params['pretrain_model'] = pretrain_model
        all_params = {k:eval(params[k]) if k in instances_param_names else params[k] for k in params}
        return data_list, model_dir, all_params
    if type == 'test':
        sec3 = 'test_path'
        test_params = cf.get_config_dict(sec3)
        model_name = test_params['model_name']
        model_path = os.path.join(model_dir, model_name)
        predict_dir = test_params['predict_dir']
        time_now = time.strftime('%Y%m%d%H-%M', time.localtime())
        save_predict_dir = os.path.join(predict_dir, time_now)
        test_data_dir = cf.getconfig(sec1, 'test_data_dir')
        for f in os.listdir(test_data_dir):
            if '.tfrecords' in f:
                data_list.append(os.path.join(test_data_dir, f))
        params.update(test_params)
        all_params = {k:eval(params[k]) if k in instances_param_names else params[k] for k in params}
        return data_list, (model_path, save_predict_dir), all_params


