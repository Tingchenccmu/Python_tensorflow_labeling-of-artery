import tensorflow as tf

def _soft_one_hot(indices, n_class, confidence=1.0):
    if n_class == 1:
        low_confidence = 1.0 - confidence
    else:
        low_confidence = (1.0 - confidence) / (n_class-1)
    soft_targets = tf.one_hot(indices, depth=n_class, on_value=confidence, off_value=low_confidence)
    return soft_targets

def mse_loss(y_true, y_pred):
    return tf.reduce_mean((y_true - y_pred)**2)

def binary_cross_entropy(y_true, y_pred):
    # one-hot
    y_true = tf.cast(y_true, tf.float32)
    y_pred = tf.clip_by_value(y_pred, 1e-6,1.0-1e-6)

    return -tf.reduce_mean(y_true * tf.log(y_pred))


def wce_loss(y_true, y_pred, n_class, class_weights):
    # y_true = tf.one_hot(tf.cast(y_true, tf.int32), n_class)
    y_true = _soft_one_hot(y_true, n_class)
    y_pred = tf.clip_by_value(y_pred, 1e-6,1.0-1e-6)

    # if class_weights != None:
    #     class_weights = 1.
    score = class_weights * y_true * tf.log(y_pred)
    score = -tf.reduce_sum(score, -1)
    return tf.reduce_mean(score)


def dice_coef(y_true, y_pred, smooth=1e-5):
    # for tensorflow
    # 2 class: sigmoid
    y_pred = tf.reshape(y_pred, [-1, 1])
    y_true = tf.reshape(y_true, [-1, 1])
    y_true = tf.cast(y_true, tf.float32)
    y_pred = tf.cast(y_pred, tf.float32)
    intersection = tf.reduce_sum(y_true * y_pred)
    union = smooth + tf.reduce_sum(y_pred) + tf.reduce_sum(y_true)
    dice = (2. * intersection + smooth) / union
    return dice


def dice_loss(y_true, y_pred):
    return 1 - dice_coef(y_true, y_pred)


def dice_loss_multiclass(y_true, y_pred, n_class, smooth=1e-5):
    y_true = tf.cast(tf.one_hot(y_true, n_class), tf.float32)
    y_true = tf.reshape(y_true, [-1, n_class])
    y_pred = tf.reshape(y_pred, [-1, n_class])
    intersection = tf.reduce_sum(y_true * y_pred, axis=0)
    union = tf.reduce_sum(y_true, axis=0) + tf.reduce_sum(y_pred, axis=0)
    dice = (2 * intersection + smooth) / (union + smooth)
    dice = tf.clip_by_value(dice, smooth, 1.0 - smooth)
    loss = tf.reduce_mean(1-dice)
    return loss


# generalized dice loss
def generalized_dice_coef(y_true, y_pred, n_class, smooth=1e-5):

    y_true = tf.cast(tf.one_hot(y_true, n_class), tf.float32)
    w = tf.reduce_sum(y_true, axis=(0,1,2,3))
    w = 1. / (w**2 + smooth)

    numerator = y_true * y_pred
    numerator = w * tf.reduce_sum(numerator, (0,1,2,3))
    numerator = tf.reduce_sum(numerator)

    denominator = y_true + y_pred
    denominator = w * tf.reduce_sum(denominator, (0,1,2,3))
    denominator = tf.reduce_sum(denominator)
    gen_dice_coef = (2 * numerator + smooth) / (denominator + smooth)
    return gen_dice_coef


def generalized_dice_loss(y_true, y_pred, n_class):
    return 1 - generalized_dice_coef(y_true, y_pred, n_class)


def weighted_dice(y_true, y_pred, weight):
    smooth = 1.
    w, m1, m2 = weight, y_true, y_pred
    intersection = (m1 * m2)
    score = (2. * tf.reduce_sum(w * intersection) + smooth) / (tf.reduce_sum(w * m1) + tf.reduce_sum(w * m2) + smooth)
    return score


def weighted_dice_loss(y_true, y_pred, weight):
    return 1. - weighted_dice(y_true, y_pred, weight)


def explog_loss(y_true, y_pred, n_class, g_d=0.3, g_c=0.3, eps=1e-5, add_err=False, class_relation_weights=None):
    y_true = tf.reshape(y_true, [-1, n_class])
    y_pred = tf.reshape(y_pred, [-1, n_class])
    y_true = tf.cast(y_true, tf.float32)

    y_pred = tf.clip_by_value(y_pred, eps, 1.0-eps)
    # dice
    intersection = tf.reduce_sum(y_true * y_pred, axis=0)
    union = tf.reduce_sum(y_true, axis=0) + tf.reduce_sum(y_pred, axis=0)
    dice = (2 * intersection + eps) / (union + eps)
    dice = tf.clip_by_value(dice, eps, 1.0-eps)
    dice_log = -tf.log(dice)

    Ld = tf.reduce_mean(tf.pow(dice_log, g_d))
    # cross entropy
   if add_err:
        y_pred_tmp = y_pred * y_true + (1-y_pred) * (1-y_true)
        if class_relation_weights is not None:
            print('class relation weights:')
            class_relation_weights1 = tf.convert_to_tensor(class_relation_weights, dtype=tf.float32)
            class_relation_weights1 = class_relation_weights1 / tf.reduce_sum(class_relation_weights1, axis=1)
            pixel_weights = tf.matmul(y_true, class_relation_weights1)
            wce = weights * pixel_weights * tf.pow(-tf.log(y_pred_tmp), g_c)
        else:
            wce = weights * tf.pow(-tf.log(y_pred_tmp), g_c)
    else:
        wce = weights * y_true * tf.pow(-tf.log(y_pred), g_c)
    Lc = tf.reduce_mean(tf.reduce_sum(wce, axis=-1))
    score = w_d * Ld + w_c * Lc
    return score


def explog_loss_nobg(x_input, y_true, y_pred, n_class, weights, confidence=0.9, w_d=0.8, w_c=0.2, g_d=0.3, g_c=0.3, eps=1e-5):
    y_true = _soft_one_hot(y_true, n_class+1, confidence)
    y_true = y_true[..., 1:]
    y_true = tf.reshape(y_true, [-1, n_class])
    x_input = tf.expand_dims(x_input,4)
    y_pred = y_pred * x_input
    y_pred = tf.reshape(y_pred, [-1, n_class])
    y_pred = tf.clip_by_value(y_pred, eps, 1.0-eps)
    # dice
    intersection = tf.reduce_sum(y_true * y_pred, axis=0)
    union = tf.reduce_sum(y_true, axis=0) + tf.reduce_sum(y_pred, axis=0)
    dice = (2 * intersection + eps) / (union + eps)
    dice = tf.clip_by_value(dice, eps, 1.0-eps)
    dice_log = -tf.log(dice)

    Ld = tf.reduce_mean(tf.pow(dice_log, g_d))
    # cross entropy
    wce = y_true * weights* tf.pow((-tf.log(y_pred)), g_c)
    Lc = tf.reduce_mean(tf.reduce_sum(wce, axis=-1))
    score = w_d * Ld + w_c * Lc
    return score

def explog_dist_loss(y_true, y_pred, n_class, weights, confidence=0.9, w_d=0.8, w_c=0.2, g_d=0.3, g_c=0.3, eps=1e-5):

    y_true = tf.reshape(y_true, [-1, n_class])
    y_pred = tf.reshape(y_pred, [-1, n_class])
    y_pred = tf.clip_by_value(y_pred, eps, 1.0-eps)
    # dice
    wd = 3.
    dist_map = (1 - y_true) * wd + y_true
    intersection = tf.reduce_sum(y_true * y_pred, axis=0)
    union = tf.reduce_sum(y_true*dist_map, axis=0) + tf.reduce_sum(y_pred, axis=0)
    dice = (2 * intersection + eps) / (union + eps)
    dice = tf.clip_by_value(dice, eps, 1.0-eps)
    dice_log = -tf.log(dice)
    # Ld = tf.reduce_mean(dice_log)

    Ld = tf.reduce_mean(tf.pow(dice_log, g_d))
    # cross entropy
    wce = dist_map*y_true * weights* tf.pow((-tf.log(y_pred)), g_c)
    Lc = tf.reduce_mean(tf.reduce_sum(wce, axis=-1))
    score = w_d * Ld + w_c * Lc
    return dice_log, Lc, score

def explog_focal_loss(y_true, y_pred, n_class, weights, w_d=0.8, w_c=0.2, g_d=0.3, g_c=0.3, eps=1e-5):

    y_true = tf.one_hot(tf.cast(y_true, tf.int32), n_class)
    # y_true = tf.cast(y_true, tf.float32)
    y_true = tf.reshape(y_true, [-1, n_class])
    y_pred = tf.reshape(y_pred, [-1, n_class])
    y_pred = tf.clip_by_value(y_pred, 1e-5, 1.0-1e-5)
    # dice
    intersection = tf.reduce_sum(y_true * y_pred, axis=0)
    union = tf.reduce_sum(y_true, axis=0) + tf.reduce_sum(y_pred, axis=0)
    dice = (2 * intersection + eps) / (union + eps)
    dice = tf.clip_by_value(dice, 1e-5, 1.0-1e-5)
    dice_log = -tf.log(dice)
    # Ld = tf.reduce_mean(dice_log)

    Ld = tf.reduce_mean(tf.pow(dice_log, g_d))
    # cross entropy
    logp = tf.log(y_pred)
    wce = tf.pow((1 - y_true*logp),g_c) * weights* tf.pow(-logp, g_c)
    Lc = tf.reduce_mean(tf.reduce_sum(wce, axis=-1))
    score = w_d * Ld + w_c * Lc
    return dice_log, Lc, score


def explog_tversky_loss(y_true, y_pred, n_class, weights, w_d=0.8, w_c=0.2, g_d=0.3, g_c=0.3, eps=1e-5):

    y_true = tf.one_hot(tf.cast(y_true, tf.int32), n_class)
    y_true = tf.reshape(y_true, [-1, n_class])
    y_pred = tf.reshape(y_pred, [-1, n_class])
    y_pred = tf.clip_by_value(y_pred, 1e-5, 1.0-1e-5)
    # dice
    tv = tversky(y_true, y_pred, alpha=0.7)
    tv = tf.clip_by_value(tv, 1e-5, 1.0-1e-5)
    tv_log = -tf.log(tv)

    Ld = tf.reduce_mean(tf.pow(tv_log, g_d))
    # cross entropy
    wce = y_true * weights* tf.pow((-tf.log(y_pred)), g_c)
    Lc = tf.reduce_mean(tf.reduce_sum(wce, axis=-1))
    score = w_d * Ld + w_c * Lc
    return score

def vessel_elog_shape_loss(y_true, y_pred, n_class, weights):
    # y_true: [batch, h, w, d]
    # y_pred: [batch, h, w, d, n_class]
    y_pred_out = tf.argmax(y_pred, -1)
    y_pred_out = tf.cast(tf.greater_equal(y_pred_out, 1), tf.float32)
    shape_loss =  binary_cross_entropy(y_true, y_pred_out)
    elog_loss = explog_loss(y_true, y_pred, n_class, weights)
    return shape_loss, elog_loss, shape_loss+elog_loss


def explog_loss_nb(y_true, y_pred, n_class, weights, w_d=0.8, w_c=0.2, g_d=0.3, g_c=0.3, eps=1e-5):
    # remove backgroud
    y_true = tf.one_hot(tf.cast(y_true, tf.int32), n_class)
    # y_true = tf.cast(y_true, tf.float32)
    y_true = tf.reshape(y_true, [-1, n_class])
    y_pred = tf.reshape(y_pred, [-1, n_class])
    y_pred = tf.clip_by_value(y_pred, 1e-5, 1.0-1e-5)
    # dice
    intersection = tf.reduce_sum(y_true * y_pred, axis=0)
    union = tf.reduce_sum(y_true, axis=0) + tf.reduce_sum(y_pred, axis=0)
    dice = (2 * intersection + eps) / (union + eps)
    dice = tf.clip_by_value(dice, 1e-5, 1.0-1e-5)
    dice_log = -tf.log(dice)
    # Ld = tf.reduce_mean(dice_log)

    Ld = tf.reduce_mean(tf.pow(dice_log, g_d))
    # cross entropy
    wce = y_true * weights* tf.pow((-tf.log(y_pred)), g_c)
    # Lc = tf.pow((-tf.log(y_pred), g_c) * weights
    Lc = tf.reduce_mean(tf.reduce_sum(wce, axis=-1))
    score = w_d * Ld + w_c * Lc
#     return Ld, Lc, score
    return score


def tversky(y_true, y_pred, alpha=0.5, smooth=1e-5):
    true_pos = tf.reduce_sum(y_true * y_pred, axis=0)
    false_neg = tf.reduce_sum(y_true * (1-y_pred), axis=0)
    false_pos = tf.reduce_sum((1-y_true)*y_pred, axis=0)
    return (true_pos + smooth)/(true_pos + alpha*false_neg + (1-alpha)*false_pos + smooth)


def tversky_loss(y_true, y_pred, alpha=0.5, smooth=1e-5):
    return 1 - tversky(y_true, y_pred, alpha, smooth)


def focal_loss(y_true, y_pred, alpha=0.25, gamma=2.):
    
    # sigmoid as the last activation
#     y, p = y_true, y_pred
    y_pred = tf.squeeze(y_pred)
    y_true = tf.squeeze(y_true)
    pt_1 = tf.where(tf.equal(y_true, 1), y_pred, tf.ones_like(y_pred))
    pt_0 = tf.where(tf.equal(y_true, 0), y_pred, tf.zeros_like(y_pred))
#     y = tf.cast(y, tf.float32)
#     p = tf.clip_by_value(p, 1e-7, 1-1e-7)
    score = -alpha * tf.pow(1-pt_1, gamma) * tf.log(pt_1) - (1-alpha) * tf.pow(pt_0, gamma) * tf.log(1-pt_0)
    score = tf.reduce_mean(score)
    return score


def dice_focal_loss(y_true, y_pred, n_class, focal_weight=0.5):
    y_true = tf.one_hot(tf.cast(y_true, tf.int32), n_class)
    y_true = tf.reshape(y_true, [-1, n_class])
    y_pred = tf.reshape(y_pred, [-1, n_class])
    y_pred = tf.clip_by_value(y_pred, 1e-6,1.0-1e-6)
    
    def tversky_loss(alpha=0.7, smooth=1e-5):
        # increase alpha to increase recall rate
        tp = tf.reduce_sum(y_true * y_pred, axis=0)
        fn = tf.reduce_sum(y_true * (1. - y_pred), axis=0)
        fp = tf.reduce_sum(y_pred * (1. - y_true), axis=0)
        return n_class - tf.reduce_sum((tp+smooth) / (tp + alpha*fn+(1-alpha)*fp)+smooth)
    
    def focal_loss():
       
        score = -tf.reduce_sum(y_true * tf.pow(1-y_pred, 2.)*tf.log(y_pred), axis=-1)
        return tf.reduce_mean(score)
    
    Ld = tversky_loss()
    Lf = focal_loss()
    
    loss = Ld + focal_weight*Lf
#     return Ld, Lf, loss
    return loss


def Active_Contour_Loss(y_true, y_pred):
    """
    lenth term
    """
    #  original x dims [b, c, h, w]
    #  update: x dims [b, d, h, w, c]
    # horizontal and vertical directions
    b, d, h, w, c = y_pred.get_shape().as_list()
    y_true = tf.reshape(y_true, (b, d, h, w, 1))
    y_true = tf.cast(y_true, tf.float32)
    z = y_pred[:, 1:, :, :, :] - y_pred[:, :-1, :, :, :]
    x = y_pred[:, :, 1:, :, :] - y_pred[:, :, :-1, :, :]
    y = y_pred[:, :, :, 1:, :] - y_pred[:, :, :, :-1, :]
    delta_z = z[:, 1:, :-2, :-2, :] ** 2
    delta_x = x[:, :-2, 1:, :-2, :] ** 2
    delta_y = y[:, :-2, :-2, 1:, :] ** 2
    delta_u = tf.abs(delta_x + delta_y + delta_z)
    lenth = tf.reduce_mean(tf.sqrt(delta_u + 0.00000001))  # equ.(11) in the paper
    """
    region term
    """
    C_1 = tf.ones_like(y_pred)
    C_2 = tf.zeros_like(y_pred)
    region_in = tf.abs(tf.reduce_mean(y_pred * ((y_true - C_1) ** 2)))  # equ.(12) in the paper
    region_out = tf.abs(tf.reduce_mean((1 - y_pred) * ((y_true - C_2) ** 2)))  # equ.(12) in the paper

    lambdaP = 1  # lambda parameter could be various.
    mu = 1  # mu parameter could be various.

    return lenth + lambdaP * (mu * region_in + region_out)


def get_cost_fun(y_true, y_pred, n_class, cost_name, weight=1., label_confidence=1., x_input=None, add_err=False, class_relation_weights=None):
    
    if cost_name == 'dl':
        return dice_loss(y_true, y_pred)

    if cost_name == 'dlm':
        return dice_loss_multiclass(y_true, y_pred, n_class)

    if cost_name == 'gdl':
        return generalized_dice_loss(y_true, y_pred, n_class)
    
    if cost_name == 'wdl':
        return weighted_dice_loss(y_true, y_pred, weight)

    if cost_name == 'wcel':
        return wce_loss(y_true, y_pred, n_class, weight)
    
    if cost_name == 'elogl':
        return explog_loss(y_true, y_pred, n_class, weight, label_confidence, add_err=add_err, class_relation_weights=class_relation_weights)
    
    if cost_name == 'elognb':
        return explog_loss_nobg(x_input, y_true, y_pred, n_class, weight, label_confidence)

    if cost_name =='elogl_dist':
        return explog_dist_loss(y_true, y_pred, n_class, weight, label_confidence)

    if cost_name == 'focal':
        return focal_loss(y_true, y_pred)

    if cost_name == 'df':
        return dice_focal_loss(y_true, y_pred, n_class)

    if cost_name == 'elog_shape':
        return vessel_elog_shape_loss(y_true, y_pred, n_class, weight)
    
    if cost_name == 'elog_t':
        return explog_tversky_loss(y_true, y_pred, n_class, weight)

    if cost_name == 'acl':
        return Active_Contour_Loss(y_true, y_pred)

    if cost_name == 'mse':
        return mse_loss(y_true, y_pred)
    
    if cost_name == 'bce':
        return binary_cross_entropy(y_true, y_pred)

    raise Exception('Loss is not matched!')
    # return wce_loss(y_true, y_pred, n_class, weight)

