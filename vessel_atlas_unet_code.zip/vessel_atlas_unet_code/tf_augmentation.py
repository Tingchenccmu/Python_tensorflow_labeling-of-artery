import numpy as np
import tensorflow as tf
import elasticdeform.tf as etf
import random

# augmentation image and label
aug_map = {0: 'central_crop_img_label_3d', 1: 'flip_lr_img_label', 2: 'rotate_img_label', 3: 'offset_img_label', 4: 'adjust_br_img_label', 5: 'add_noise_img_label', 6: 'zoom_img_label_3d', 7:'deform_grid', 8:'adjust_contrast_img_label', 9:'adjust_gamma_img_label'}
heavy_aug = [2, 3, 6, 7]
light_aug = [0, 1, 4, 5, 8, 9]

def _random_number(minval, maxval, n, data_type):
    """Return n random 0-D tensor between minval and maxval."""
    if n == 0:
        return tf.random.uniform([], minval=minval, maxval=maxval, dtype=data_type)
    return tf.random.uniform([n], minval=minval, maxval=maxval, dtype=data_type)

def random_integer(n, minval, maxval):
    return _random_number(minval, maxval, n, tf.int32)

def random_float(n, minval, maxval):
    """Return a random 0-D tensor between minval and maxval."""
    return _random_number(minval, maxval, n, tf.float32)

def randomSizes(xy_size,minv,maxv):
    RAND = random_float(2, minv, maxv)
    newsize = tf.cast(tf.convert_to_tensor(xy_size), tf.float32)*RAND
    return tf.cast(newsize, tf.int32)

def randomSizes_3d(xyz_size,minv,maxv):
    RAND = random_float(3, minv, maxv)
    newsize = tf.cast(tf.convert_to_tensor(xyz_size), tf.float32)*RAND
    return tf.cast(newsize, tf.int32)

def randomOffset(xy_size):
    RAND = random_float(2, -0.1, 0.1)
    offset = tf.cast(tf.convert_to_tensor(xy_size), tf.float32)*RAND
    return tf.cast(offset, tf.int32)

def linear_normalization(x):
    x = tf.cast(x, tf.float32)
    minv = tf.reduce_min(x)
    maxv = tf.reduce_max(x)
    return (x - minv) / (maxv - minv)


def z_score_normalization(x):
    return tf.image.per_image_standardization(x)


def zoomTF(x, image_shape, size, tr_only=False,interpolation='BILINEAR'):
    with tf.name_scope('zoomTF'):
        image_shape = tf.cast(image_shape, tf.float32)
        zsize = tf.cast(size, tf.float32)
        h_frac = 1.0*image_shape[0]/zsize[0]
        w_frac = 1.0*image_shape[1]/zsize[1]
        hd = 0.5*h_frac*(zsize[0] - image_shape[0])
        wd = 0.5*w_frac*(zsize[1] - image_shape[1])
        zoom_tr = tf.convert_to_tensor([h_frac, 0, hd, 0, w_frac, wd, 0, 0])
        zoom_tr = tf.expand_dims(zoom_tr, axis=0)
        if tr_only:
            out = zoom_tr
        else:
            out = tf.contrib.image.transform(x, zoom_tr, interpolation=interpolation)
    return out


def padding_img_label(img, label, ori_size, target_size):
    pad_h = tf.maximum(0, (target_size[0] - ori_size[0]) // 2 + 1)
    pad_w = tf.maximum(0, (target_size[1] - ori_size[1]) // 2 + 1)
    pad_d = tf.maximum(0, (target_size[2] - ori_size[2]) // 2 + 1)
    img = tf.pad(img, [[pad_h, pad_h], [pad_w, pad_w], [pad_d, pad_d]])
    label = tf.pad(label, [[pad_h, pad_h], [pad_w, pad_w], [pad_d, pad_d]])
    pad_box = [pad_h, pad_w, pad_d]
    return img, label, pad_box


def random_crop_img_label(img, label, ori_size, target_size):
    img, label, pad_box  = padding_img_label(img, label, ori_size, target_size)
    offset_h = random_integer(0, 0, ori_size[0]+2*pad_box[0] - target_size[0] + 1)
    offset_w = random_integer(0, 0, ori_size[1]+2*pad_box[1] - target_size[1] + 1)
    offset_d = random_integer(0, 0, ori_size[2]+2*pad_box[2] - target_size[2] + 1)
    patch_img = img[offset_h:offset_h + target_size[0], offset_w:offset_w + target_size[1], offset_d:offset_d + target_size[2]]
    patch_label = label[offset_h:offset_h + target_size[0], offset_w:offset_w + target_size[1], offset_d:offset_d + target_size[2]]
    return patch_img, patch_label


def center_crop_img_label(img, label, ori_size, target_size):
    target_h, target_w, target_d = target_size
    img, label, pad_box = padding_img_label(img, label, ori_size, target_size)
    offset_x = (ori_size[0]+2*pad_box[0]-target_h)//2
    offset_y = (ori_size[1]+2*pad_box[1]-target_w)//2
    offset_z = (ori_size[2]+2*pad_box[2]-target_d)//2
    patch_img = img[offset_x:offset_x+target_h, offset_y:offset_y+target_w, offset_z:offset_z+target_d]
    patch_label = label[offset_x:offset_x+target_h, offset_y:offset_y+target_w, offset_z:offset_z+target_d]
    return patch_img, patch_label


def rotate_img_label(img, label, max_angle=30, **kwargs):
    # input, img(d, h, w)
    print('rotate')
    angle = random_float(0, -(max_angle * 3.14 / 180.0), max_angle * 3.14 / 180.0)
    interpolation = kwargs['interpolation']
    img = tf.transpose(img, [1,2,0])
    label = tf.transpose(label, [1,2,0])
    img_aug = tf.contrib.image.rotate(img, angle, interpolation=interpolation)  # NHWC
    label_aug = tf.contrib.image.rotate(label, angle, interpolation='NEAREST')
    img_aug = tf.transpose(img_aug, [2,0,1])
    label_aug = tf.transpose(label_aug, [2,0,1])
    return img_aug, label_aug


def flip_lr_img_label(img, label, **kwargs):
    print('flip')
    img_aug = tf.image.flip_left_right(img)
    label_aug = tf.image.flip_left_right(label)
    return img_aug, label_aug


def central_crop_img_label(img, label, minv=0.78, maxv=0.9, **kwargs):
    print('crop')
    RAND = random.uniform(minv, maxv)
    img_aug = tf.image.central_crop(img, central_fraction=RAND)
    img_size = kwargs['img_size']
    img_aug = tf.image.resize_image_with_crop_or_pad(img_aug, img_size[0], img_size[1])
    label_aug = tf.image.central_crop(label, central_fraction=RAND)
    label_aug = tf.image.resize_image_with_crop_or_pad(label_aug, img_size[0], img_size[1])
    return img_aug, label_aug

def central_crop_img_label_3d(img, label, minv=0.7, maxv=0.9,  **kwargs):
    print('crop')
    def centeral_crop_im(img, crop_size, img_size):
        # crop_size, img_size: (h,w,d)
        img_aug = tf.image.resize_image_with_crop_or_pad(img, crop_size[0], crop_size[1])
        img_aug = tf.transpose(img_aug,[2,1,0])
        img_aug = tf.image.resize_image_with_crop_or_pad(img_aug, crop_size[2], crop_size[1])
        img_aug = tf.image.resize_image_with_crop_or_pad(img_aug, img_size[2], img_size[1])
        img_aug = tf.transpose(img_aug,[2,1,0])
        img_aug = tf.image.resize_image_with_crop_or_pad(img_aug, img_size[0], img_size[1])
        return img_aug
    img_size = kwargs['img_size']
    crop_size = randomSizes_3d(img_size,minv, maxv)
    img_crop = centeral_crop_im(img, crop_size, img_size)
    label_crop = centeral_crop_im(label, crop_size, img_size)
    return img_crop, label_crop

def zoom_img_label(img, label, minv=0.85, maxv=1.2, **kwargs):
    print('zoom')
    img_size = kwargs['img_size']
    interpolation = kwargs['interpolation']
    zooming = randomSizes(img_size[:2], minv, maxv)
    img_aug = zoomTF(img, img_size, zooming, interpolation=interpolation)
    label_aug = zoomTF(label, img_size, zooming, interpolation='NEAREST')
    return img_aug, label_aug

def zoom_img_label_3d(img, label, minv=0.85, maxv=1.2, **kwargs):
    print('zoom')
    def zoom_img(img, zoom_size, img_size):
        img_aug = tf.image.resize_images(img, zoom_size[:2], method=tf.image.ResizeMethod.NEAREST_NEIGHBOR)
        img_aug = tf.image.resize_image_with_crop_or_pad(img_aug,img_size[0],img_size[1])
        img_aug = tf.transpose(img_aug, [2,1,0])
        img_aug = tf.image.resize_images(img_aug, [zoom_size[2],img_size[1]],method=tf.image.ResizeMethod.NEAREST_NEIGHBOR)
        img_aug = tf.image.resize_image_with_crop_or_pad(img_aug, img_size[2],img_size[1])
        img_aug = tf.transpose(img_aug, [2,1,0])
        return img_aug
    img_size = kwargs['img_size']
    interpolation = kwargs['interpolation']
    zoom_size = randomSizes_3d(img_size, minv, maxv)
    zom_img = zoom_img(img, zoom_size, img_size)
    zom_label = zoom_img(label, zoom_size, img_size)
    return zom_img, zom_label

def adjust_br_img_label(img, label, max_delta=10, **kwargs):
    print('adjust brightness')
    img_aug = tf.image.random_brightness(img, max_delta)
    return img_aug, label


def adjust_contrast_img_label(img, label, lower=0.8, upper=1.1, **kwargs):
    img = tf.expand_dims(img, axis=0)
    img = tf.transpose(img, [3, 1, 2, 0])
    img1 = linear_normalization(img)
    img1 = tf.image.random_contrast(img1, lower, upper)
    img1 = tf.squeeze(tf.transpose(img1, [0, 1, 2, 3]))
    return img1, label


def add_noise_img_label(img, label, **kwargs):
    #     print('add noise')
    img_size = kwargs['img_size']
    noise = tf.random.normal(img_size, mean=0, stddev=0.05, dtype=tf.float32)
    img_aug = tf.add(img, noise)
    return img_aug, label


def adjust_gamma_img_label(img, label, lower=0.8, upper=1.2, **kwargs):
    img1 = linear_normalization(img)
    gamma = random_float(0, lower, upper)
    img_aug = img1 ** gamma
    return img_aug, label

def offsetTF(x, xy_offset, tr_only=False,interpolation='BILINEAR'):
    with tf.name_scope('randomOffset'):
        # vol must be of shape [batch or z, y, x, channels]
        xy_offset = tf.cast(xy_offset, tf.float32)
        offset_tr = tf.convert_to_tensor( \
            [1., 0., xy_offset[0], 0., 1., xy_offset[1], 0., 0.], dtype=tf.float32)
        if tr_only:
            out = tf.expand_dims(offset_tr, axis=0)
        else:
            out = tf.contrib.image.transform(x, offset_tr, interpolation=interpolation)
    return out

def offset_img_label(img, label, **kwargs):
    #     print('offset')
    img_size = kwargs['img_size']
    interpolation = kwargs['interpolation']
    xy_offset = randomOffset(img_size[:2])
    img_aug = offsetTF(img, xy_offset, interpolation=interpolation)
    if label is not None:
        label_aug = offsetTF(label, xy_offset, interpolation='NEAREST')
    return img_aug, label_aug


def deform_grid(X, Y, min_sigma=3, max_sigma=10, order_x=0, order_y=0, axis=(1, 2), grid_shape=3, **kwargs):
    sigma = tf.random_uniform([], minval=min_sigma, maxval=max_sigma)
    dims = len(axis)
    displacement = tf.random.normal([dims]+[grid_shape]*dims) * sigma
    # the deform_grid function is similar to the plain Python equivalent,
    # but it accepts and returns TensorFlow Tensors
    X_deformed, Y_deformed = etf.deform_grid([X, Y], displacement, axis=[axis, axis], order=[order_x, order_y])
    return X_deformed, Y_deformed

def vessel_deform(img, label, **kwargs):
    return deform_grid(img, label, 5, 25, 0, 0)


def tf_aug(img, label, aug_choices, **params):
    # aug_type: heavy(interpolation computation) or light
    def f1(img, label, func, **params):
        img, label = func(img, label, **params)
        img = tf.reshape(img, params['img_size'])
        label = tf.cast(tf.reshape(label, params['img_size']), tf.uint8)
        return img, label

    for sid in aug_choices:
        img, label = tf.cond(tf.less(random_float(0, 0, 1), 0.5), lambda: f1(img, label, eval(aug_map[sid]), **params),
                             lambda: (img, label))
    return img, label


def tf_aug_select1(img, label, aug_choices, **params):
    def f1(func):
        img1, label1 = func(img, label, **params)
        img1 = tf.reshape(img1, params['img_size'])
        label1 = tf.cast(tf.reshape(label1, params['img_size']), tf.uint8)
        return img1, label1

    elems = tf.convert_to_tensor(aug_choices)
    sid = random_integer(0, 0, len(aug_choices))
    select_id = elems[sid]
    #     tf.print('select_id:',[select_id])
    img_aug, label_aug = tf.case([(tf.equal(select_id, 0), lambda: f1(central_crop_img_label)),
                                  (tf.equal(select_id, 1), lambda: f1(flip_lr_img_label)),
                                  (tf.equal(select_id, 2), lambda: f1(rotate_img_label)),
                                  (tf.equal(select_id, 3), lambda: f1(offset_img_label)),
                                  (tf.equal(select_id, 4), lambda: f1(adjust_br_img_label)),
                                  (tf.equal(select_id, 5), lambda: f1(add_noise_img_label)),
                                  (tf.equal(select_id, 6), lambda: f1(zoom_img_label)),
                                  (tf.equal(select_id, 7), lambda: f1(vessel_deform)),
                                  (tf.equal(select_id, 8), lambda: f1(adjust_contrast_img_label)),
                                  (tf.equal(select_id, 9), lambda: f1(adjust_gamma_img_label))],
                                 default=lambda: (img, label))
    return img_aug, label_aug


def aug_choose(feat_dict, interpolation, aug_selection_list):
    # aug_type: heavy or light
    img, label = tf_aug_select1(feat_dict['tof'], feat_dict['label'], aug_selection_list, interpolation=interpolation,
                                img_size=feat_dict['shape'])
    return {'tof': img, 'label': label, 'shape': feat_dict['shape'], 'name': feat_dict['name']}


def random_crop_aug(feat_dict, target_shape):
    # return dict for parse
    img, label = random_crop_img_label(feat_dict['tof'], feat_dict['label'], feat_dict['shape'], target_shape)
    return {'tof': img, 'label': label, 'shape': target_shape, 'name': feat_dict['name']}


def center_crop_aug(feat_dict, target_shape):
    # return dict for parse
    img, label = center_crop_img_label(feat_dict['tof'], feat_dict['label'], feat_dict['shape'], target_shape)
    return {'tof': img, 'label': label, 'shape': target_shape, 'name': feat_dict['name']}