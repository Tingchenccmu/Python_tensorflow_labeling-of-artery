import logging
import time
import os

    
def loadLogger(log_dir=None):
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    formatter = logging.Formatter(fmt= "[%(asctime)s] %(message)s", datefmt="%a %b %d %H:%M:%S %Y")
    
    sHandler = logging.StreamHandler()
    sHandler.setFormatter(formatter)
    
    logger.addHandler(sHandler)
    
    if log_dir is not None:
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
        fHandler = logging.FileHandler(os.path.join(log_dir, 'log.txt'), mode='w')
        fHandler.setLevel(logging.INFO)
        fHandler.setFormatter(formatter)

        logger.addHandler(fHandler)
    
    return logger

