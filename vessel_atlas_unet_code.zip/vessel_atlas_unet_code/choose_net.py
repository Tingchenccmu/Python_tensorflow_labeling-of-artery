
import sys
sys.path.append('..')
import numpy as np

def importer(name, root_package=False, relative_globals=None, level=0):
    """ We only import modules, functions can be looked up on the module.
    Usage:

    from foo.bar import baz
    # >>> baz = importer('foo.bar.baz')

    import foo.bar.baz
    # >>> foo = importer('foo.bar.baz', root_package=True)
    #  >>> foo.bar.baz

    from .. import baz (level = number of dots)
    # >>> baz = importer('baz', relative_globals=globals(), level=2)
    """
    return __import__(name, locals=None, # locals has no use
                      globals=relative_globals,
                      fromlist=[] if root_package else [None],
                      level=level)

def choose_net(img_tf, **params):

    unet_opt_dic = {
                    'unet':'unet.Model.Model3d',
                   }

    model_version = params['model_version']
    if model_version not in unet_opt_dic:
        return None

    strs = unet_opt_dic[model_version].split('.')
    pkg = '.'.join(strs[:-1])
    method = strs[-1]
    module = __import__(pkg, fromlist=[method])
    model = getattr(module, method)
    net = model(img_tf, **params)
    return net

if __name__ == '__main__':
    choose_net(np.zeros((3,3,3)), model_version='unet')