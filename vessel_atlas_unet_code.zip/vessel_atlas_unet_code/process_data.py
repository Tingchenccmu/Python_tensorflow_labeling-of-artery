'''
### Image segmentation practice

1. preprocess the image data: format, augmentation
2. get the train,val, test data set
3. model 
4. train
5. test and evaluation
'''
import tensorflow as tf
import SimpleITK as sitk
import os
import numpy as np
import scipy
import matplotlib.pyplot as plt
import random


def select_gpu(use_gpus_str='', gpus_num=1):
    if len(use_gpus_str) > 0:
        os.environ['CUDA_VISIBLE_DEVICES']= use_gpus_str
    else:
        os.system('nvidia-smi -q -d Memory |grep -A4 GPU|grep Free >gpu_mem.txt')
        memory_gpu = [int(x.split()[2]) for x in open('gpu_mem.txt','r').readlines()]
        memory_dict = {i:x for i,x in enumerate(memory_gpu)}
        print(memory_dict)
        memory_arr = sorted(memory_dict.items(), key=lambda x:x[1], reverse=True)
        use_list = [x[0] for x in memory_arr[:gpus_num]]
#         use_list = [str(x) for x in use_list if x != 0]
        use_list = [str(x) for x in use_list]
        use_str = ','.join(use_list)
        print('max memory_gpu', use_str)
        os.environ['CUDA_VISIBLE_DEVICES']= use_str
        os.system('rm gpu_mem.txt')
        return use_list

def plotit(images, cols=2, slice_id=35):
    f, axes = plt.subplots(int(len(images)/cols), cols)
    print('ok')
    for axis, image in zip(axes.ravel(), images):
        if image.shape[-1] == 3:
            axis.imshow(image[:,:, :]) 
        else:
            # axis.imshow(image[:,:, image.shape[-1]//2], cmap='gray')
            print(image.shape)
            # axis.imshow(image[:,:, image.shape[-1]//2])
            axis.imshow(image[:,:, slice_id])
    plt.show()
    
def read_img_sitk(img_path, get_space_origin=False, trans=False):
    img_itk = sitk.ReadImage(img_path)
    if trans:
        img = sitk.GetArrayFromImage(img_itk).transpose([1,2,0])
    else:
        img = sitk.GetArrayFromImage(img_itk)
    space = img_itk.GetSpacing()
    origin = img_itk.GetOrigin()
    if get_space_origin:
        return img, space, origin
    return img

def save_img_sitk(img_arr, img_path, space=None, origin=None, trans=False):
    if trans:
        img_arr = img_arr.transpose([2,0,1])
    img = sitk.GetImageFromArray(img_arr)
    if space is not None:
        img.SetSpacing(space)
    if origin is not None:
        img.SetOrigin(origin)
    sitk.WriteImage(img, img_path)


def read_img_sitk_ref(img_path, trans=False):
    img_itk = sitk.ReadImage(img_path)
    if trans:
        img_arr = sitk.GetArrayFromImage(img_itk).transpose([1, 2, 0])
    else:
        img_arr = sitk.GetArrayFromImage(img_itk)
    return img_itk, img_arr


def save_img_sitk_ref(img_arr, ref_itk, img_path, trans=False):
    if trans:
        img_arr = img_arr.transpose([2,0,1])
    img_itk = sitk.GetImageFromArray(img_arr)
    img_itk.CopyInformation(ref_itk)
    sitk.WriteImage(img_itk, img_path)

def relabel_img(img, relabel_map):
    img_cp = img.copy()
    for k, v in relabel_map.items():
        img_cp[img == k] = v
    return img_cp

def show_img_sitk(img, slice_id):
    plt.imshow(img[slice_id,:,:], cmap='gray')
    plt.show()
    
def normalize(img):
    # for one image
    normal_img = z_score(img)
    minv = np.min(normal_img)
    maxv = np.max(normal_img)
    res = (normal_img - minv) / (maxv - minv)  
    return res

def z_score(img):
    res = (img - np.mean(img)) / np.std(img)
    return res

def normalize_cta(img, lb = None, ub = None):
    '''
    Normalize CT image. if no lb and ub defined, then use min and max of HU value
    '''
    if lb is None: lb=np.amin((img))
    if ub is None: ub=np.amax((img))
    img = img.astype(np.float32)
    # using in-place operation
    img = np.subtract(img, lb, img)
    img = np.divide(img, ub-lb, img)
    img[img<0.] = 0.
    img[img>1.] = 1.
    return img
 

def scale(img):
    # for multi-image normalization together
    # mean, variance = tf.nn.moments(img, axes=0)
    mean = np.mean(img, axis=(1,2,3),keepdims=True)
    # print('mean.shape', mean.shape)
    variance = np.std(img, axis=(1,2,3), keepdims=True)
    img = (img - mean)/variance 
    minv = np.min(img, axis=(1,2,3), keepdims=True)
    maxv = np.max(img, axis=(1,2,3),keepdims=True)
    # print(minv)
    # print(maxv)
    img = (img - minv) / (maxv - minv)
    return img

def show_img(img, slice_id,save_path=None):
    plt.imshow(img[:,:,slice_id], cmap='gray')
    if save_path is not None:
        plt.axis('off')
        plt.savefig(save_path, bbox_inches='tight', dpi=300)
    plt.show()
    
    
def threshold_p(img_data, thre=96.5):
    img_copy = img_data.copy()
    p = np.percentile(img_copy, thre)
    # print('p = ', p)
    img_copy[img_copy<p] = 0
    return img_copy


def bbox_3D(img, depth=True):
    # get the boundary in which pixel is not zero
    r = np.any(img, axis=(1, 2)) # judge if any channel has 1 value(True value)
    c = np.any(img, axis=(0, 2))
    z = np.any(img, axis=(0, 1))
    rmin, rmax = np.where(r)[0][[0, -1]]
    cmin, cmax = np.where(c)[0][[0, -1]]
    zmin, zmax = np.where(z)[0][[0, -1]]
    if depth:
        return (rmin, rmax, cmin, cmax,zmin, zmax)
    return (rmin, rmax, cmin, cmax,0, img.shape[2])


def padding3D(img,pd_shape):
    # padding a 3D image to a fixed size
    shape = img.shape
    res_shape = [max(shape[0],pd_shape[0]),max(shape[1],pd_shape[1]),max(shape[2],pd_shape[2])]
    res = np.zeros(res_shape)
    gap_w = 0
    gap_h = 0
    gap_d = 0
    if shape[0] <  pd_shape[0]:
        gap_w = int(( pd_shape[0] - shape[0]) / 2)
    if shape[1] < pd_shape[1]:
        gap_h = int(( pd_shape[1] - shape[1]) / 2)
    if shape[2] < pd_shape[2]:
        gap_d = int(( pd_shape[2] - shape[2]) / 2)
    res[gap_w:gap_w + shape[0] ,gap_h:gap_h + shape[1] ,gap_d:gap_d+shape[2]] = img
    print('padding from',shape,'to',res_shape)
    return res

def padding3D_box(img, pd_shape, r=False):
    # padding a 3D image to a fixed size
    # if r = True, padding along the z axis will from the bottom
    shape = img.shape
    res_shape = [max(shape[0], pd_shape[0]), max(shape[1], pd_shape[1]), max(shape[2], pd_shape[2])]
    res = np.zeros(res_shape)
    gap_w = 0
    gap_h = 0
    gap_d = 0
    if shape[0] < pd_shape[0]:
        gap_w = int((pd_shape[0] - shape[0]) / 2)
    if shape[1] < pd_shape[1]:
        gap_h = int((pd_shape[1] - shape[1]) / 2)
    if shape[2] < pd_shape[2]:
        if r:
            gap_d = 0
        else:
            gap_d = int((pd_shape[2] - shape[2]) / 2)
    res[gap_w:gap_w + shape[0], gap_h:gap_h + shape[1], gap_d:gap_d + shape[2]] = img
    gap_leftcorner = [gap_w, gap_h, gap_d]
    return res, gap_leftcorner

def crop_from_centre_brain(img, crop_shape, trans=True, depth_start=0):
    # the brain aivessel crop method is different from coronary artery
    # brain aivessel crop from buttom
    # if depth_start == 0, start from 0; depth_start=-1, crop from center; other values x  > 0, start from x
    ori_shape = img.shape
    res = np.zeros(crop_shape)
    crop_cube = [0, 0, 0]
    if ori_shape[0] >= crop_shape[0] and ori_shape[1] >= crop_shape[1] and ori_shape[2] >= crop_shape[2]:
        start0 = ori_shape[0] // 2 - crop_shape[0] // 2
        start1 = ori_shape[1] // 2 - crop_shape[1] // 2
        start2 = ori_shape[2] // 2 - crop_shape[2] // 2
        if trans:
            start2 = depth_start if depth_start !=-1 else start2
        else:
            start0 = depth_start if depth_start !=-1 else start0
        res = img[start0:start0 + crop_shape[0]:, start1:start1 + crop_shape[1], start2:start2 + crop_shape[2]]
        crop_cube = [start0, start1, start2]
    return res, crop_cube

def extract_random_patches(full_img, full_label, patch_h, patch_w, N_patches):
    h, w, d = full_img.shape
    half_patch_h = patch_h // 2
    half_patch_w = patch_w // 2
    patches = []
    for i in range(N_patches):
        center_w = random.randint(0+half_patch_w, w-half_patch_w)
        center_h = random.randint(0+half_patch_h, h-half_patch_h)

        patch = full_img[center_h-half_patch_h:center_h+half_patch_h, center_w-half_patch_w: center_w+half_patch_w, :]
        patch_label = full_label[center_h-half_patch_h:center_h+half_patch_h, center_w-half_patch_w: center_w+half_patch_w, :]

        patches.append((patch, patch_label))
    return patches

def extract_ordered_overlap_patches(full_img, patch_h, patch_w, stride_h, stride_w):
    h, w, d = full_img.shape
    patches = []
    for i in range((h-patch_h)//stride_h+1):
        for j in range((w-patch_w)//stride_w+1):
            patch = full_img[i*stride_h:i*stride_h+patch_h, j*stride_w:j*stride_w+patch_w, :]
            patches.append(patch)
    return patches

def extract_ordered_overlap_patches_depth(full_img, patch_h, patch_w, patch_d,  stride_h, stride_w, stride_d):
    h, w, d = full_img.shape
    patches = []
    for i in range((h-patch_h)//stride_h+1):
        for j in range((w-patch_w)//stride_w+1):
            for k in range((d-patch_d)//stride_d+1):
                patch = full_img[i*stride_h:i*stride_h+patch_h, j*stride_w:j*stride_w+patch_w, k*stride_d:k*stride_d+patch_d]
                patches.append(patch)
    return patches

def crop_from_center_with_padding(img, crop_shape, depth_side_crop=False):
    shape = img.shape
    # res = np.zeros(crop_shape)
    w = crop_shape[0]
    h = crop_shape[1]
    d = crop_shape[2]
    if (shape[0] < w or shape[1] < h or shape[2] < d):
        img = padding3D(img, (w + 4, h + 4, d + 4))
        shape = img.shape
    
    if shape[0] >= w and shape[1] >= h and shape[2]>=d:
        center = [int(shape[0]/2),int(shape[1]/2),int(shape[2]/2)]
        start_w = center[0] - w//2
        start_h = center[1] - h//2
        start_d = center[2] - d//2
        if depth_side_crop:
            return img[start_w:start_w + w , start_h:start_h + h, 0:d]
        img = img[start_w:start_w + w , start_h:start_h + h, start_d:start_d+d]
    return img

def crop_from_center(img, crop_shape, depth_side_crop=False):
    h0, w0, d0 = img.shape
    ch, cw, cd = crop_shape
    hl, hr, wl, wr, dl, dr = bbox_3D(img)
    half_h, half_w, half_d = ch//2, cw//2, cd//2

    center_h = hl + (hr - hl)//2
    center_w = wl + (wr - wl)//2
    center_d = dl + (dr - dl)//2

    bhl, bhr = center_h - half_h, center_h + half_h
    bwl, bwr = center_w-half_w, center_w+half_w
    bdl, bdr = center_d-half_d, center_d+half_d

    if bhl < 0  or bhr > d0 or bwl < 0 or bwr > w0 or bdl < 0 or bdr > 0:
        crop_bx = img[hl:min(h0, hl+ch), wl:min(w0, wl+cw),dl:min(d0,dl+cd)]
        start_pos = (hl, wl, dl)
        h,w,d = crop_bx.shape
        if h != crop_shape[0] or w != crop_shape[1] or d != crop_shape[2]:
            res = np.zeros(crop_shape)
            res[0:h, 0:w, 0:d] = crop_bx
            crop_bx = res
    else:
        if depth_side_crop:
            crop_bx = img[bhl:bhr, bwl:bwr, 0:cd]
            start_pos = (bhl, bwl, 0)
        else:
            crop_bx = img[bhl:bhr, bwl:bwr, bdl:bdr]
            start_pos = (bhl, bwl, bdl)
    return crop_bx, start_pos

def resize(img, r_shape, include_depth=False, order = 0):
    zoom_w = r_shape[0]/img.shape[0]
    zoom_h = r_shape[1]/img.shape[1]
    zoom_d = 1
    if not include_depth:
        zoom_d =  r_shape[2]/img.shape[2]

    res = scipy.ndimage.zoom(img, zoom=(zoom_w,zoom_h,zoom_d),order=order)
    # res = scipy.ndimage.interpolation.zoom(img, zoom=(zoom_w,zoom_h,zoom_d)) 
    return res

def resize_img(img, r_shape, include_depth=True, order=0):
    zoom_d = 1
    zoom_h = r_shape[1]/img.shape[1]
    zoom_w = r_shape[2]/img.shape[2]
    if include_depth:
        zoom_d = r_shape[0]/img.shape[0]
    res = scipy.ndimage.zoom(img, zoom=(zoom_d, zoom_h,zoom_w), order=order)
    return res