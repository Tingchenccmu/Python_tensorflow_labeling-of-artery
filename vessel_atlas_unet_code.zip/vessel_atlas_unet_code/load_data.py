

from tf_augmentation import *

def maxpooling3d(img):
    return tf.layers.max_pooling3d(img, pool_size=(2, 2, 2), strides=(2,2,2), padding='valid')

def parse_func(serialized_example, cta_clip=None):
    """

    :param serialized_example:
    :param cta_clip: for CTA TOF image input, None default
    :return: feature dict: {'tof': tof, 'label': label, 'name': name, 'shape': shape}
    """
    features = {
        'tof': tf.io.FixedLenFeature(shape=(), dtype=tf.string),
        'label': tf.io.FixedLenFeature(shape=(), dtype=tf.string),
        'shape': tf.io.FixedLenFeature(shape=[3], dtype=tf.int64),
        'name': tf.io.FixedLenFeature(shape=(), dtype=tf.string)
    }
    parsed_example = tf.io.parse_single_example(serialized_example, features)
    tof = tf.decode_raw(parsed_example['tof'], tf.int16)
    label = tf.decode_raw(parsed_example['label'], tf.uint8)
    tof = tf.reshape(tof, parsed_example['shape'])
    label = tf.reshape(label, parsed_example['shape'])
    if cta_clip is not None:
        tf.clip_by_value(tof, cta_clip[0], cta_clip[1])
    out_feats = {'tof': tf.cast(tof, tf.float32), 'label': label, 'name': parsed_example['name'], 'shape': tf.cast(parsed_example['shape'], tf.int32)}
    return out_feats


def make_batch_iterator(tfrecord_path, batch_size, img_shape, random_crop, is_training, heavy_choices, light_choices,
                           interpolation='NEAREST', compress=False, echo=False, img_normalize=False,maxpooling=False):
    """

    :param tfrecord_path: path list, str for each element
    :param batch_size: int
    :param img_shape: tuple or list, (h,w,d)
    :param random_crop: bool
    :param is_training: bool
    :param heavy_choices: list, int for each element
    :param light_choices: list, int for each element
    :param interpolation: str, NEAREST default
    :param compress: bool
    :param echo: bool
    :param img_normalize: bool, False for binary input
    :return: next example, dict,{'tof': tof, 'label':label, 'shape':shape, 'name':name}
    """

    repeat_num = 3  # repeat num or data echo numbers
    num_parallel = 4
    echo_num = 2
    buffer_size = 8

    def _heavy_aug(example_proto):
        return tf.cond(tf.greater_equal(random_integer(0, 0, 9), 2),
                       lambda: aug_choose(example_proto, interpolation, heavy_choices), lambda: example_proto)

    def _light_aug(example_proto):
        return tf.cond(tf.greater_equal(random_integer(0, 0, 9), 2),
                       lambda: aug_choose(example_proto, interpolation, light_choices), lambda: example_proto)

    def _random_crop(example_proto):
        return random_crop_aug(example_proto, img_shape)

    def _center_crop(example_proto):
        return center_crop_aug(example_proto, img_shape)

    def _img_norm(example_proto):
        img = z_score_normalization(example_proto['tof'])
        img = linear_normalization(img)
        example_proto['tof'] = img
        return example_proto
    
    def _maxpooling3d(example_proto):
        img = example_proto['tof']
        label = example_proto['label']
        shape = example_proto['shape']
        img = tf.reshape(img, [1, shape[0],shape[1],shape[2], 1])
        label = tf.reshape(label, [1, shape[0],shape[1],shape[2], 1])
        img = maxpooling3d(img)
        label = maxpooling3d(tf.cast(label, tf.float32))
        new_shape = [(shape[0]-2)//2+1, (shape[1]-2)//2+1,(shape[2]-2)//2+1]
        
        example_proto['tof'] = tf.reshape(img, new_shape)
        example_proto['label'] = tf.cast(tf.reshape(label, new_shape), tf.uint8)
        example_proto['shape'] = new_shape
        return example_proto

    if compress:
        dataset = tf.data.TFRecordDataset(tfrecord_path, compression_type="ZLIB")
    else:
        dataset = tf.data.TFRecordDataset(tfrecord_path)
    if is_training:
        dataset = dataset.shuffle(buffer_size)
    dataset = dataset.map(parse_func, num_parallel_calls=num_parallel)
    if maxpooling:
        dataset = dataset.map(_maxpooling3d, num_parallel_calls=num_parallel)

    if is_training:
        if random_crop:
            dataset = dataset.map(_random_crop, num_parallel_calls=num_parallel)
        if len(heavy_choices) >= 1:
            dataset = dataset.map(_heavy_aug, num_parallel_calls=num_parallel)
        if echo:
            dataset = dataset.flat_map(lambda t: tf.data.Dataset.from_tensors(t).repeat(echo_num))
        if len(light_choices) >= 1:
            dataset = dataset.map(_light_aug, num_parallel_calls=num_parallel)
    else:
        dataset = dataset.map(_center_crop, num_parallel_calls=num_parallel)
    if img_normalize:
        dataset = dataset.map(_img_norm, num_parallel_calls=num_parallel)
    dataset = dataset.batch(batch_size, drop_remainder=True)
    dataset = dataset.prefetch(-1)
    return dataset.make_initializable_iterator()
