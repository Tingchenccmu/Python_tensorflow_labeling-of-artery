
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
import argparse
from load_data import *
import numpy as np
from load_config_params import *
from choose_net import choose_net
from costs import *
from metrics import *
from get_logger import loadLogger
import sys
sys.path.append('../unet')
from tf_utils import exponential_decay_with_warmup
sys.path.append('../utils')
from process_data import select_gpu
import memory_saving_gradients as gc


def train_model(train_tfr_path_list, val_tfr_path_list, model_dir, logger, **model_para):
    """
    :param logger:
    :param model_para: dict, prameters
    :return:
    """
    # load parameters
    n_class = model_para['n_class']
    batch_size = model_para['batch_size']
    cost_name = model_para['loss_fun']
    learning_rate = model_para['learning_rate']
    class_weights = model_para.get('class_weights', 1.)
    input_size = model_para['input_size']
    epochs = model_para['epochs']
    optimizer_name = model_para['optimizer_name']
    shrink = model_para['shrink']

    interpolation = model_para.get('interpolation', 'NEAREST')
    log_dir = model_para.get('log_dir', 'logs/')
    pretrain_model = model_para.get('pretrain_model', '')
    warmup = model_para.get('warmup', False)
    warmup_step = model_para.get('warmup_step', 3)
    show_step = model_para.get('show_step', 20)
    decay_steps = model_para.get('decay_steps', 5000)
    compress = model_para.get('compress', False)  # whether compress in tfrecords
    random_crop = model_para.get('random_crop', False)
    img_normalize = model_para.get('img_normalize', False)
    decay_method = model_para.get('decay_method', 'exp')
    label_confidence = model_para.get('label_confidence', 1.0)
    echo = model_para.get('echo', False)
    aug_choice = model_para.get('aug_choice', [])
    is_maxpool = model_para.get('maxpooling', False)
    pretrain_mode = model_para.get('pretrain_mode', 'all')
    class_relation_dic =  model_para.get('class_relation_weights', {})
    add_err =  model_para.get('add_err', False)
    class_relation_weights = np.eye(n_class, n_class)
    class_relation_weights[class_relation_weights==0] = 10
    for k, v in class_relation_dic.items():
        class_relation_weights[k[0]][k[1]] = v
        class_relation_weights[k[1]][k[0]] = v

    print('pretrain_mode: ', pretrain_mode)
    heavy_choices = [one for one in aug_choice if one in heavy_aug]
    light_choices = [one for one in aug_choice if one in light_aug]

    class_relation_weights = np.eye(n_class, n_class)
    class_relation_weights[class_relation_weights == 0] = 10
    for k, v in class_relation_dic.items():
        class_relation_weights[k[0]][k[1]] = v
        class_relation_weights[k[1]][k[0]] = v

    # load data
    train_iterator = make_batch_iterator(train_tfr_path_list, batch_size, input_size, random_crop, True, heavy_choices, light_choices,
                           interpolation=interpolation, compress=compress, echo=echo, img_normalize=img_normalize, maxpooling=is_maxpool)
    train_batch_data = train_iterator.get_next()
    train_img_tf, train_lbl_tf = train_batch_data['tof'], train_batch_data['label']
    train_lbl_tf = tf.cast(tf.one_hot(train_lbl_tf, n_class), tf.float32)
    train_net = choose_net(train_img_tf, **model_para)
    train_pred_tf = train_net.inference()

    val_iterator = make_batch_iterator(val_tfr_path_list, batch_size, input_size, False, False, [], [],
                           interpolation=interpolation, compress=compress, echo=echo, img_normalize=img_normalize, maxpooling=is_maxpool)
    val_batch_data = val_iterator.get_next()
    val_img_tf, val_lbl_tf = val_batch_data['tof'], val_batch_data['label']
    val_lbl_tf = tf.cast(tf.one_hot(val_lbl_tf, n_class), tf.float32)
    val_net = choose_net(val_img_tf, **model_para)
    val_pred_tf = val_net.inference()

    # loss
    if model_para['model_version'] == 'suatt':
        train_loss_tf = train_net.exp_loss(train_pred_tf[0], train_pred_tf[1], train_lbl_tf)
        val_loss_tf = val_net.exp_loss(val_pred_tf[0], val_pred_tf[1], val_lbl_tf)
        train_dice_all_tf = out_dice_coef(train_lbl_tf, train_pred_tf[1], n_class)
        val_dice_all_tf = out_dice_coef(val_lbl_tf, val_pred_tf[1], n_class)
        
    elif cost_name == 'elognb':
        train_loss_tf = get_cost_fun(train_lbl_tf, train_pred_tf, n_class, cost_name, class_weights,label_confidence=label_confidence, x_input=train_img_tf)
        val_loss_tf = get_cost_fun(val_lbl_tf, val_pred_tf, n_class, cost_name, class_weights,label_confidence=label_confidence, x_input=val_img_tf)
        train_dice_all_tf = out_dice_coef_rmlabel(train_img_tf, train_lbl_tf, train_pred_tf, n_class) 
        val_dice_all_tf = out_dice_coef_rmlabel(val_img_tf, val_lbl_tf, val_pred_tf, n_class)
    else:
        # with tf.device('cpu:0'):
        train_loss_tf = get_cost_fun(train_lbl_tf, train_pred_tf, n_class, cost_name, class_weights,label_confidence=label_confidence, add_err=add_err, class_relation_weights=class_relation_weights)
        val_loss_tf = get_cost_fun(val_lbl_tf, val_pred_tf, n_class, cost_name, class_weights,label_confidence=label_confidence, add_err=add_err, class_relation_weights=class_relation_weights)

        train_dice_all_tf = out_dice_coef(train_lbl_tf, train_pred_tf, n_class)
        val_dice_all_tf = out_dice_coef(val_lbl_tf, val_pred_tf, n_class)

    train_dice_tf = tf.reduce_mean(train_dice_all_tf)
    val_dice_tf = tf.reduce_mean(val_dice_all_tf)


    # learning rate
    global_steps = tf.Variable(0, trainable=False)
    print('decay steps: ', decay_steps)
    if decay_steps != 0:
        if warmup:
            print('warmpup')
            learning_rate_decay = exponential_decay_with_warmup(warmup_step,learning_rate, global_steps, decay_steps, shrink)
        else:
            if decay_method == 'cosine_restart':
                learning_rate_decay = tf.train.cosine_decay_restarts(learning_rate, global_steps, decay_steps,
                                      t_mul=2.0, m_mul=0.95, alpha=0.0)
            elif decay_method == 'cosine':
                learning_rate_decay = tf.train.cosine_decay(learning_rate, global_steps, decay_steps)
            elif decay_method == 'exp':
                # default
                learning_rate_decay = tf.train.exponential_decay(learning_rate, global_steps, decay_steps, shrink, staircase=False)
            else:
                learning_rate_decay = learning_rate
    else:
        learning_rate_decay = learning_rate

    # optimizer
    if optimizer_name == 'adam':
        optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate_decay)
    else:
        optimizer = tf.train.GradientDescentOptimizer(learning_rate=learning_rate_decay)
    
    # monitor
    avg_loss_tf = tf.placeholder(tf.float32)
    avg_dice_tf = tf.placeholder(tf.float32)
    lr_tf = tf.summary.scalar('learning_rate', learning_rate_decay)
    avg_loss_summary_tf = tf.summary.scalar('loss', avg_loss_tf)
    avg_dice_summary_tf = tf.summary.scalar('dice', avg_dice_tf)

    # model saver
    curr_saver = tf.train.Saver(max_to_keep=epochs, keep_checkpoint_every_n_hours=1)
    # pretrain
    pretrain_flag = False
    variables = tf.contrib.framework.get_variables_to_restore()
    print('tensor length: ', len(variables))
    if os.path.exists(pretrain_model + '.index'):
        pretrain_flag = True
        if pretrain_mode == 'all':
            logger.info('Load all parameters')
            variables_to_restore = variables
            variables_to_train = variables
        if pretrain_mode == 'nohead':
            logger.info('Load parameters except head')
    #       variables = tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES)
            variables_to_restore = [v for v in variables if not v.name.startswith('last_conv')]
            variables_to_train = variables_to_restore
        if pretrain_mode == 'encoder_freeze':
            logger.info('Load encoder and freeze')
            variables_to_restore = [v for v in variables if v.name.startswith('conv') and int(v.name.split('/')[0][-1]) <= 5]
            variables_to_train = [v for v in variables if v not in variables_to_restore]
            train_op = optimizer.minimize(train_loss_tf, var_list=variables_to_train,  global_step=global_steps)

        before_saver = tf.train.Saver(variables_to_restore, max_to_keep=None, keep_checkpoint_every_n_hours=1) 
        variables_to_init = [v for v in tf.global_variables() if v not in variables_to_restore]
        init_op = tf.variables_initializer(variables_to_init)
    else:
        train_op = optimizer.minimize(train_loss_tf, global_step=global_steps)
        before_saver = tf.train.Saver(max_to_keep=epochs, keep_checkpoint_every_n_hours=1)
        init_op = tf.global_variables_initializer()
        

    val_best_dice = 0
    best_model_path = ''
    with tf.Session() as sess:
        sess.run(init_op)
        if pretrain_flag:
            before_saver.restore(sess, pretrain_model)
        train_writer = tf.summary.FileWriter(os.path.join(log_dir, 'train'), sess.graph)
        val_writer = tf.summary.FileWriter(os.path.join(log_dir, 'valid'))
        global_count = 0

        for epoch in range(epochs):
            logger.info(f'***************** Training epoch: {epoch}**********************')
            sess.run(train_iterator.initializer)
            i = 0
            train_loss_avg = 0
            train_dice_avg = 0
            while True:
                try:
                    try:
                        _, train_loss = sess.run([train_op, train_loss_tf])
                        i += 1
                        global_count += 1
                        train_loss_avg += train_loss

                        if global_count % show_step == 0:                          
                            logger.info(f'\t [Epoch {epoch}, step {i}] Train loss: {train_loss}')
                            lr_val, av_loss_val = sess.run([lr_tf, avg_loss_summary_tf], feed_dict={avg_loss_tf: train_loss_avg / i})
                            train_writer.add_summary(lr_val, global_step=global_count)
                            train_writer.add_summary(av_loss_val, global_step=global_count)
                        
                    except tf.errors.DataLossError as e:
                        logger.error('Dataloss')
                except tf.errors.OutOfRangeError as e:
                    logger.info(f'End of {i} steps for train: ')
                    break
            
            logger.info(f'\t [Epoch {epoch}]: Train avg loss: {train_loss_avg/i}')
            # ************************************ validation ******************************************
            logger.info(f" Eval epoch: {epoch}")
            val_loss_avg = 0
            val_dice_avg = 0
            j = 0
            sess.run(val_iterator.initializer)
            while True:
                try:
                    val_loss, val_dice = sess.run([val_loss_tf, val_dice_tf])
                    val_loss_avg += val_loss
                    val_dice_avg += val_dice
                    j += 1
                except tf.errors.OutOfRangeError as e:
                    # logger.warning(f'End of {j} steps for validation!')
                    break
            val_loss_avg /= j
            val_dice_avg /= j

            av_loss_val1, av_dice_val1 = sess.run([avg_loss_summary_tf, avg_dice_summary_tf],
                                                  feed_dict={avg_loss_tf: val_loss_avg, avg_dice_tf: val_dice_avg})
            val_writer.add_summary(av_loss_val1, global_step=epoch)
            val_writer.add_summary(av_dice_val1, global_step=epoch)
            val_writer.flush()

            logger.info(f'\t [Epoch {epoch}]: Eval avg loss: {val_loss_avg}, Eval avg dice:{val_dice_avg}')
            if val_dice_avg > val_best_dice:
                val_best_dice = val_dice_avg
                best_model_path = os.path.join(model_dir, f'epoch{epoch}_{val_dice_avg}_model')
                curr_saver.save(sess, best_model_path, write_meta_graph=False)
    return val_best_dice, best_model_path



if __name__ == '__main__':
    select_gpu()
    ap = argparse.ArgumentParser()
    ap.add_argument("-p", '--config_path', required=True, help="The path of config file")
    args = vars(ap.parse_args())
    config_filepath = args['config_path']
    st = time.time()
    data_list, model_dir, all_params = load_params(config_filepath, 'train')

    train_tfr_list, val_tfr_list = data_list
    logger = loadLogger(model_dir)
    cf = Config(config_filepath)
    cf.print_config('train_params', logger)
    val_best_dice, best_model_path = train_model(train_tfr_list, val_tfr_list, model_dir,logger, **all_params)
    endt = time.time()
    print(f'Train finished! During time: {round((endt-st)/60)} min')
    print(f'Validation best dice is: {val_best_dice}, the model saved in {best_model_path}')

