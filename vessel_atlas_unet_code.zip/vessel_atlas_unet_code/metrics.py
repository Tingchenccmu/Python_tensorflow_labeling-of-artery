import tensorflow as tf
import matplotlib.pyplot as plt
import numpy as np
from skimage.morphology import skeletonize_3d, binary_dilation
from scipy.ndimage import generate_binary_structure, binary_dilation, binary_fill_holes
from skimage import measure
from process_data import read_img_sitk, save_img_sitk, read_img_sitk_ref, save_img_sitk_ref

def dice_coef1(y_true, y_pred, smooth=1e-5):
    # for tensorflow
    # 2 class: sigmoid
    y_pred = tf.reshape(y_pred, [-1, 1])
    y_true = tf.reshape(y_true, [-1, 1])
    intersection = tf.reduce_sum(y_true * y_pred)
    union = smooth + tf.reduce_sum(y_pred) + tf.reduce_sum(y_true)
    dice = (2. * intersection + smooth) / union
    return dice

def dice_coef_multiclass(y_true, y_pred, n_class, class_weights, smooth=1e-5):
    # for tensorflow
    # multi class: sigmoid
    y_pred = tf.reshape(y_pred, [-1, n_class])
    y_true = tf.one_hot(tf.cast(y_true, tf.int32), n_class)
    y_true = tf.reshape(y_true, [-1, n_class])
    intersection = tf.reduce_sum(y_true * y_pred, axis=0)
    union = smooth + tf.reduce_sum(y_pred, axis=0) + tf.reduce_sum(y_true, axis=0)
    dice_class = (2. * intersection + smooth) / union
    class_weights = np.array(class_weights)
    weights_sum = np.sum(class_weights)
    class_weights /= weights_sum
    dice = tf.reduce_mean(dice_class * class_weights)
    return dice

def dice_loss_multiclass(y_true, y_pred, n_class, smooth=1e-5):
    return 1.0 - dice_coef_multiclass(y_true, y_pred, n_class, smooth)

def out_dice_coef(y_true, y_pred, n_class, smooth=10):
    y_pred = tf.argmax(y_pred, -1)
    y_pred = tf.one_hot(y_pred, n_class)
    y_pred = y_pred[..., 1:]
    y_true = y_true[..., 1:]
    intersection = tf.reduce_sum(y_pred * y_true, axis=(0,1,2,3))
    union = tf.reduce_sum(y_pred, axis=(0,1,2,3)) + tf.reduce_sum(y_true, axis=(0,1,2,3))
    score = (2*intersection + smooth)/ (union + smooth)
    return score

def out_dice_coef_rmlabel(x_input, y_true, y_pred, n_class, smooth=10):
    # y_pred is final output, argmax
    # y_true is one-hot format
    x_input = tf.cast(tf.squeeze(x_input,0), tf.int32)
    y_pred = (tf.cast(tf.argmax(y_pred, -1), tf.int32)+1)*x_input
    y_pred = tf.one_hot(y_pred, n_class+1)
    y_pred = y_pred[..., 1:]
    y_true = y_true[..., 1:]
    intersection = tf.reduce_sum(y_pred * y_true, axis=(0,1,2,3))
    union = tf.reduce_sum(y_pred, axis=(0,1,2,3)) + tf.reduce_sum(y_true, axis=(0,1,2,3))
    score = (2*intersection + smooth)/ (union + smooth)
    return score

def out_dice_coef_batch(y_true, y_pred, n_class, smooth=10):
    y_pred = tf.argmax(y_pred, -1)
    y_pred = tf.one_hot(y_pred, n_class)
    y_true = tf.one_hot(y_true, n_class)
    y_pred = y_pred[..., 1:]
    y_true = y_true[..., 1:]
    intersection = tf.reduce_sum(y_pred * y_true, axis=(1,2,3))
    union = tf.reduce_sum(y_pred, axis=(1,2,3)) + tf.reduce_sum(y_true, axis=(1,2,3))
    score = (2*intersection + smooth)/ (union + smooth)
    return score

def dice_loss(y_true, y_pred, smooth=1e-5):

    dice = dice_coef1(y_true, y_pred, smooth)
    dloss = 1 - dice
    return dloss


def wce_loss(w1, w2, pred_tf, lbl_tf): 
    # w1, w2 are the weights for the 2 class 1 and 0
    wceLoss = -tf.reduce_mean(w1*lbl_tf * tf.log(pred_tf) + w2*(1.-lbl_tf)*tf.log(1.-pred_tf))
    return wceLoss

def wce_loss_multiclass(pred_tf, lbl_tf, n_class, class_weights):
    lbl_tf = tf.cast(lbl_tf, tf.int32)
    lbl_tf = tf.one_hot(lbl_tf, n_class)
    return -tf.reduce_mean(class_weights * lbl_tf * tf.log(pred_tf))

def get_pr(pred_tf, lbl_tf):
    # 2 class, pred_tf includes 1 and 0
    tp = tf.reduce_sum(tf.multiply(pred_tf, lbl_tf))
    all_p = tf.reduce_sum(pred_tf)
    real_p = tf.reduce_sum(lbl_tf)
    precision_tf = tp / all_p
    recall_tf = tp / real_p
    return precision_tf, recall_tf


def draw_curve(train_list, val_list, title):
    x = [i for i in range(len(train_list))]
    fig,ax = plt.subplots()
    ax.plot(x, train_list, color='red')
    ax.plot(x,val_list,color='blue')
    ax.set_xlabel('epochs')
    ax.set_ylabel('value')
    ax.set_title(title)
    ax.legend(['train','val'])
    plt.show()


def multi_dice_np(gt,pred,n_class,smooth=1, class_names=None):
    '''
    multi-class dice
    :param gt:
    :param pred:
    :param n_class:
    :param smooth:
    :return:
    '''
    grade = 100
    gt = gt.astype(np.int)
    pred = pred.astype(np.int)
    matrix_image = gt * 100 + pred
    dict_matrix = np.zeros([n_class,n_class])
    all_key = np.bincount(matrix_image.flatten())
    dice_list = [0] * n_class
    for i, count in enumerate(all_key):
        if count == 0:
            continue
        p = i % grade
        t = i // grade
        dict_matrix[t][p] = count
    for i in range(1, n_class):
        TP = dict_matrix[i, i]
        FP = np.sum(dict_matrix[:, i]) - TP
        FN = np.sum(dict_matrix[i, :]) - TP
        dice = (2*TP+smooth)/(2*TP+FN+FP+smooth)
        dice_list[i] = dice
    if class_names is None:
        res = {'class'+str(i):dice_list[i] for i in range(1, n_class)}
    else:
        res = {class_names[i]:dice_list[i] for i in range(1, n_class)}
    res['average_dice'] = np.mean(dice_list[1:n_class])
    return res


def multi_dice_sk(seg, gt, pred, n_class, smooth=1, output_filename):
    seg[seg != 0] = 1
    seg_sk = skeletonize_3d(seg)
    gt_sk = binary_dilation(seg_sk) * gt
    pred_sk = binary_dilation(seg_sk) * pred
    save_img_sitk(pred_sk, output_filename)
    res = multi_dice_np(gt_sk, pred_sk, n_class, smooth)
    return res

def fill_holes(seg, pred):
    pred_bi = pred.copy()
    pred_bi[pred_bi != 0] = 1
    seg[seg != 0] = 1
    holes = seg-pred_bi

    for prop in measure.regionprops(measure.label(holes)):
        min_d, min_h, min_w, max_d, max_h, max_w = prop.bbox
        if len(np.unique(pred[max(0,min_d-2):max_d+2, max(0,min_h-2):max_h+2, max(0,min_w-2):max_w+2])) == 2:
            pred[prop.slice][prop.image] = np.max(pred[min_d-2:max_d+2, min_h-2:max_h+2, min_w-2:max_w+2])
    return pred



