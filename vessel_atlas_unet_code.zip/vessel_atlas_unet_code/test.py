import sys
import os
import tensorflow as tf
# tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.INFO)
import numpy as np 
import pandas as pd
from os.path import abspath, join, dirname
CURR_PATH = abspath(__file__)
PKG_PATH  = dirname(dirname(CURR_PATH))
sys.path.insert(0, PKG_PATH)
from choose_net import choose_net
from vessel_hitting_rate import vertex_generator, vertex_diff
from metrics import *
from costs import *
from get_tfrecords import *


def test(data_path_list, file_names, model_path, save_predict_dir, model_version, **model_para):
    
    is_aug = tf.compat.v1.placeholder(tf.bool)
    keep_prob = tf.compat.v1.placeholder(tf.float32)

    # layer_channel_list = model_para['channels']
    input_size = model_para['input_size']
    # groups = model_para['groups']
    # depth = model_para['depth']
    n_class = model_para['n_class']
    activation = model_para['activation']
    # init_method = model_para['init_method']
    aug_choice = model_para.get('aug_choice', 'all')
    interpolation = model_para.get('interpolation', 'NEAREST')
    # pool_strides = model_para.get('pool_strides', (2,2,2))
    # normalize = model_para.get('normalize', 'gn')
    batch_size = model_para.get('batch_size', 1)
    # normalize = model_para.get('normalize', 'gn')
    c2 = model_para.get('c2', False) # whether two channel in label
    compress = model_para.get('compress', False) # whether compress in tfrecords
    img_type = model_para.get('img_type', 'cta')
    save_results = model_para.get('save_results', True)
    save_hit_rate = model_para.get('save_hit_rate', False)
    # print('c2:',c2, 'compress:', compress)
    iterator = make_batch_iterator(data_path_list, is_aug, batch_size, input_size, aug_choice, interpolation, shuffle=False,compress=compress, c2=c2)
    img_tf, lbl_tf = iterator.get_next()
    training = False # inference
    net = choose_net(model_version, img_tf, **model_para)

    if net is None:
        logger.info('Model does not exist!')
        return
    
    pred_tf = net.inference()
    if n_class == 2:
        lbl_tf = tf.cast(lbl_tf, tf.float32)
        lbl_tf = tf.cast(1 - tf.abs(lbl_tf - 1), tf.int32)
    if n_class == 2 and activation == 'sigmoid':
        print('sigmoid')
        output = tf.cast(tf.greater_equal(pred_tf, 0.5), tf.int32)
        dice = dice_coef(lbl_tf, output)
    else:
        # activation is 'softmax'
        print('softmax')
        # pred_tf = net.inference_multi(n_class, img_tf, input_size, keep_prob, True, groups)
        output = tf.argmax(pred_tf, -1)
        # output_look = tf.argsort(pred_tf, axis=-1, direction='ASCENDING', stable=False)
        # output_look = output_look[..., -2]
        # ins, un, dice = out_dice_coef(lbl_tf, pred_tf, n_class)
        dice = out_dice_coef(lbl_tf, pred_tf, n_class)

    dloss = generalized_dice_loss(lbl_tf, pred_tf, n_class)
        
    init_op = tf.global_variables_initializer()
    saver = tf.compat.v1.train.Saver()

    dice_list = [] 
    dices = []

    with tf.compat.v1.Session() as sess:
        # sess.run(init_op)
        saver.restore(sess, model_path)
        sess.run(iterator.initializer,  feed_dict = {is_aug:False})
        i = 0
        hard_list = []
        diff_payload_, hit_payload_ = {}, {}
        file_dir, _ = os.path.split(save_predict_dir)

        if save_results and not os.path.exists(save_predict_dir):
            os.makedirs(save_predict_dir) 
        if save_hit_rate and (img_type in ['mra_head', 'cta_head']):
            hit_flag = True
        else:
            hit_flag = False
        print('save_hit_rate: ', save_hit_rate, 'img_type:', img_type)
        while True:
            try:
          
                img, lbl, pred, loss, d = sess.run([img_tf, lbl_tf, output, dloss, dice], feed_dict = {keep_prob:1.0})
                
                img = np.squeeze(img).astype(np.float32)
                pred = np.squeeze(pred).astype(np.uint8)
                lbl = np.squeeze(lbl).astype(np.uint8)
                ds = np.average(d)
                dices.append(ds)
                if hit_flag:    
                    sep_gdt_, sep_prd_ = vertex_generator(lbl, pred, img_type=img_type)
                    diff_payload_, hit_payload_, none_k = vertex_diff(sep_gdt_, sep_prd_, diff_payload_, hit_payload_)
                name = file_names[i].replace('.tfrecords', '')
                dice_list.append([name, ds] + list(d))
                # print(f'{name}, avg dice: {ds}, class dice: {d}')

                # print('d1:', d[1])
                # if 0 < d[1] < 0.01:
                    # hard_list.append(name)
                # size = np.sum(lbl)
                # dice_list.append({'name': name, 'size': size, 'dice' : d})
                if save_results:
                    save_dir = os.path.join(save_predict_dir, name+'_'+str(ds))
                    if not os.path.exists(save_dir):
                        os.makedirs(save_dir)
                    save_img_sitk(img, os.path.join(save_dir, "raw"+ str(i) +".nii.gz"))
                    save_img_sitk(pred, os.path.join(save_dir,  "pred"+ str(i) +".nii.gz"))
                    save_img_sitk(lbl, os.path.join(save_dir, "label"+ str(i) + ".nii.gz"))
                i += 1
            except tf.errors.OutOfRangeError as e:
                df = pd.DataFrame(dice_list, columns=['pid', 'avg_dice'] + [str(i) for i in range(1, n_class)])
                csv_name = model_path.split('/')[-3]
                date = save_predict_dir.split('/')[-1]
                csv_path = os.path.join(file_dir, csv_name + '_' + date + '.csv')
                if os.path.exists(csv_path):
                    df.to_csv(csv_path, index=False, mode='a', header=False)
                else:
                    df.to_csv(csv_path, index=False)
                print('avg dice: ', np.average(dices))
                # print('hard list')
                # for x in hard_list:
                    # print(x)
                break
        if hit_flag:
            list_ind = []
            list_pinpoint = []
            list_hit_rate = []
            list_number = []

            for k, v in diff_payload_.items():
                print('vessel seg {} has pinpoint value: {}, and hitting rate {}, and number counted {}'.format(k, np.mean(v),np.mean(hit_payload_[k]),len(v)))
                list_ind.append(k)
                list_pinpoint.append(np.mean(v))
                list_hit_rate.append(np.mean(hit_payload_[k]))
                list_number.append(len(v)) 
            excel_writer = os.path.join(file_dir,  'hitrate_' + date + '.xlsx')
            writer = pd.ExcelWriter(excel_writer, engine='openpyxl')

            wb = writer.book
            df = pd.DataFrame({'ind': list_ind,
                               'pinpoint': list_pinpoint,
                               'hit_rate': list_hit_rate,
                               'hit_number': list_number})
            df.to_excel(writer, index=False)
            wb.save(excel_writer)
